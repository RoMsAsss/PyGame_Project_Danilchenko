import pygame
import sys
import random
import math
import sqlite3
import pygame.mixer

SCREEN_WIDTH = 1024
SCREEN_HEIGHT = 768
FPS = 30
FONT_NAME = "Arial"

RED         = (155, 0, 0)
ORANGE      = (255, 165, 0)
YELLOW      = (255, 255, 0)
GREEN       = (0, 128, 0)
LIGHT_BLUE  = (135, 206, 250)
BLUE        = (0, 0, 255)
VIOLET      = (5, 5, 5)
BLACK       = (245, 245, 245)
OFF_WHITE   = (55, 55, 55)
DARK_GREEN  = (0, 100, 0)
GRAY        = (128, 128, 128)
SOFT_RED = (255, 100, 100)

PALETTE_COLORS = [RED, ORANGE, YELLOW, GREEN, LIGHT_BLUE, BLUE, VIOLET, BLACK]
ERASER_LABEL = "E"

BACKGROUND_COLOR = OFF_WHITE

TOTAL_LEVELS = 20
CELL_SIZE = 30

EXIT_BUTTON_RECT = pygame.Rect(20, 20, 200, 40)

LEVEL_BUTTON_WIDTH = 80
LEVEL_BUTTON_HEIGHT = 80
LEVEL_BUTTON_MARGIN = 20

DEFAULT_THREE_STARS = 60
DEFAULT_TWO_STARS   = 120
DEFAULT_ONE_STAR    = 300

PURCHASE_COST = 500

DEFAULT_BRIGHTNESS = 0.8
SETTINGS = {"brightness": DEFAULT_BRIGHTNESS}


LEVEL_DATA = {
    1: {
        "theme": "СЕРДЕЧКО",
        "grid": [
            [0, 0, 7, 7, 0, 0, 0, 7, 7, 0, 0],
            [0, 7, 1, 1, 7, 0, 7, 1, 1, 7, 0],
            [7, 1, 1, 1, 1, 7, 1, 1, 1, 1, 7],
            [7, 1, 1, 1, 1, 1, 1, 1, 1, 1, 7],
            [0, 7, 1, 1, 1, 1, 1, 1, 1, 7, 0],
            [0, 0, 7, 1, 1, 1, 1, 1, 7, 0, 0],
            [0, 0, 0, 7, 1, 1, 1, 7, 0, 0, 0],
            [0, 0, 0, 0, 7, 1, 7, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0],
        ]
    },
    2: {
        "theme": "ПОДАРОК",
        "grid": [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 6, 6, 6, 6, 1, 6, 6, 6, 6, 0],
            [0, 6, 6, 6, 6, 1, 6, 6, 6, 6, 0],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
            [0, 6, 6, 6, 6, 1, 6, 6, 6, 6, 0],
            [0, 6, 6, 6, 6, 1, 6, 6, 6, 6, 0],
        ]
    },
    3: {
        "theme": "НОТА",
        "grid": [
            [0, 0, 0, 7, 0, 0, 0],
            [0, 0, 0, 7, 7, 0, 0],
            [0, 0, 0, 7, 7, 7, 0],
            [0, 0, 0, 7, 0, 7, 7],
            [0, 0, 0, 7, 0, 0, 7],
            [0, 0, 0, 7, 0, 0, 0],
            [0, 7, 7, 7, 0, 0, 0],
            [7, 7, 7, 7, 0, 0, 0],
            [0, 7, 7, 0, 0, 0, 0],
        ]
    },
    4: {
        "theme": "РАТМИР",
        "grid": [
            [0, 0, 7, 7, 7, 7, 7, 0, 0],
            [0, 7, 0, 0, 0, 0, 0, 7, 0],
            [7, 0, 0, 0, 0, 0, 0, 0, 7],
            [7, 0, 0, 0, 0, 0, 0, 0, 7],
            [7, 0, 0, 0, 0, 0, 0, 0, 7],
            [7, 0, 0, 0, 0, 0, 0, 0, 7],
            [0, 7, 0, 0, 0, 0, 0, 7, 0],
            [0, 0, 7, 7, 1, 7, 7, 0, 0],
            [0, 7, 7, 0, 1, 0, 7, 7, 0],
            [7, 7, 7, 0, 1, 0, 7, 7, 7],
            [7, 7, 7, 7, 1, 7, 7, 7, 7],
            [7, 0, 7, 7, 7, 7, 7, 0, 7],
            [0, 7, 7, 7, 7, 7, 7, 7, 0],
            [0, 0, 7, 7, 7, 7, 7, 0, 0],
            [0, 0, 7, 7, 0, 7, 7, 0, 0],
            [0, 0, 7, 7, 0, 7, 7, 0, 0],
        ]
    },
    5: {
        "theme": "СМАЙЛИК",
        "grid": [
            [0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0],
            [0, 0, 0, 7, 7, 3, 3, 3, 3, 3, 7, 7, 0, 0, 0],
            [0, 0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0, 0],
            [0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0],
            [0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0],
            [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7],
            [7, 3, 7, 0, 0, 7, 7, 7, 7, 0, 0, 7, 7, 3, 7],
            [7, 3, 7, 0, 7, 7, 7, 3, 7, 0, 7, 7, 7, 3, 7],
            [7, 3, 3, 7, 7, 7, 3, 3, 3, 7, 7, 7, 3, 3, 7],
            [7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7],
            [0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 7, 3, 3, 7, 0],
            [0, 7, 3, 3, 3, 7, 7, 7, 7, 7, 3, 3, 3, 7, 0],
            [0, 0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0, 0],
            [0, 0, 0, 7, 7, 3, 3, 3, 3, 3, 7, 7, 0, 0, 0],
            [0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0]
        ]
    },
    6: {
        "theme": "ТИКИ ТОКИ",
        "grid": [
            [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7],
            [7, 7, 7, 7, 7, 7, 7, 7, 5, 5, 5, 7, 7, 7, 7, 7, 7],
            [7, 7, 7, 7, 7, 7, 7, 7, 5, 0, 0, 1, 7, 7, 7, 7, 7],
            [7, 7, 7, 7, 7, 7, 7, 7, 5, 0, 0, 1, 7, 7, 7, 7, 7],
            [7, 7, 7, 7, 7, 7, 7, 7, 5, 0, 0, 0, 7, 7, 7, 7, 7],
            [7, 7, 7, 7, 7, 7, 7, 7, 5, 0, 0, 0, 0, 5, 7, 7, 7],
            [7, 7, 7, 7, 7, 7, 7, 7, 5, 0, 0, 0, 0, 0, 5, 7, 7],
            [7, 7, 7, 7, 5, 5, 7, 7, 5, 0, 0, 0, 0, 0, 0, 1, 7],
            [7, 7, 7, 5, 0, 0, 1, 7, 5, 0, 0, 1, 1, 0, 0, 1, 7],
            [7, 7, 5, 0, 0, 0, 1, 7, 5, 0, 0, 1, 7, 1, 1, 1, 7],
            [7, 7, 5, 0, 0, 0, 1, 7, 5, 0, 0, 1, 7, 7, 7, 7, 7],
            [7, 5, 0, 0, 0, 1, 7, 7, 5, 0, 0, 1, 7, 7, 7, 7, 7],
            [7, 5, 0, 0, 0, 1, 7, 7, 5, 0, 0, 1, 7, 7, 7, 7, 7],
            [7, 5, 0, 0, 0, 1, 5, 5, 0, 0, 0, 1, 7, 7, 7, 7, 7],
            [7, 7, 5, 0, 0, 0, 0, 0, 0, 0, 1, 7, 7, 7, 7, 7, 7],
            [7, 7, 7, 0, 0, 0, 0, 0, 0, 1, 7, 7, 7, 7, 7, 7, 7],
            [7, 7, 7, 1, 0, 0, 0, 1, 1, 7, 7, 7, 7, 7, 7, 7, 7],
            [7, 7, 7, 7, 1, 1, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7],
            [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7]


        ]
    },
    7: {
        "theme": "ЮТУБ",
        "grid": [
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
        ]
    },
    8: {
        "theme": "ГРИБОЧЕК",
        "grid": [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0],
            [0, 0, 0, 7, 7, 7, 0, 1, 1, 0, 7, 7, 7, 0, 0, 0],
            [0, 0, 7, 7, 0, 0, 0, 1, 1, 0, 0, 0, 7, 7, 0, 0],
            [0, 7, 7, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 7, 7, 0],
            [0, 7, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 7, 0],
            [7, 7, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 7, 7],
            [7, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 7],
            [7, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 7],
            [7, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 7],
            [7, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 7],
            [7, 1, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 1, 7],
            [7, 7, 7, 7, 0, 0, 7, 0, 0, 7, 0, 0, 7, 7, 7, 7],
            [0, 7, 7, 0, 0, 0, 7, 0, 0, 7, 0, 0, 0, 7, 7, 0],
            [0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0],
            [0, 0, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 0, 0],
            [0, 0, 0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0, 0, 0],
        ]
    },
    9: {
        "theme": "ИНЬ И ЯНЬ",
        "grid": [
            [0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 7, 7, 0, 0, 0, 0, 7, 7, 0, 0, 0, 0],
            [0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 7, 7, 0, 0, 0],
            [0, 0, 7, 0, 0, 0, 7, 7, 0, 0, 0, 7, 7, 7, 0, 0],
            [0, 7, 0, 0, 0, 0, 7, 7, 0, 0, 0, 7, 7, 7, 7, 0],
            [0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 0],
            [7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7],
            [7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7],
            [7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7],
            [7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 7],
            [7, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 7, 7, 7],
            [0, 7, 0, 0, 0, 0, 0, 7, 7, 0, 0, 7, 7, 7, 7, 0],
            [0, 7, 0, 0, 0, 0, 7, 7, 7, 0, 0, 7, 7, 7, 7, 0],
            [0, 0, 7, 0, 0, 0, 7, 7, 7, 7, 7, 7, 7, 7, 0, 0],
            [0, 0, 0, 7, 0, 0, 0, 7, 7, 7, 7, 7, 7, 0, 0, 0],
            [0, 0, 0, 0, 7, 7, 0, 0, 7, 7, 7, 7, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0]
        ]
    },
    10: {
        "theme": "ТЕЛЕВИЗОР",
        "grid": [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0],
            [0, 0, 0, 7, 0, 0, 0, 0, 7, 0, 0, 0],
            [0, 0, 0, 0, 7, 0, 0, 7, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 7, 7, 0, 0, 0, 0, 0],
            [0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0],
            [7, 7, 1, 3, 2, 4, 6, 8, 5, 7, 7, 7],
            [7, 7, 1, 3, 2, 4, 6, 8, 5, 7, 0, 7],
            [7, 7, 1, 3, 2, 4, 6, 8, 5, 7, 7, 7],
            [7, 7, 1, 3, 2, 4, 6, 8, 5, 7, 0, 7],
            [7, 7, 1, 3, 2, 4, 6, 8, 5, 7, 7, 7],
            [7, 7, 1, 3, 2, 4, 6, 8, 5, 7, 7, 7],
            [7, 7, 1, 3, 2, 4, 6, 8, 5, 7, 7, 7],
            [0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0],
        ]
    },
    11: {
        "theme": "БАКАЛ",
        "grid": [
            [0, 0, 7, 7, 7, 7, 7, 7, 7, 0, 0],
            [0, 0, 7, 0, 0, 0, 0, 0, 7, 0, 0],
            [0, 7, 0, 0, 0, 0, 0, 0, 0, 7, 0],
            [0, 7, 0, 0, 0, 0, 0, 1, 1, 7, 0],
            [7, 1, 1, 1, 1, 1, 1, 1, 1, 1, 7],
            [7, 1, 1, 1, 1, 1, 1, 1, 1, 1, 7],
            [7, 1, 1, 1, 1, 1, 1, 1, 1, 1, 7],
            [7, 1, 0, 1, 1, 1, 1, 1, 1, 1, 7],
            [0, 7, 1, 0, 1, 1, 1, 1, 1, 7, 0],
            [0, 0, 7, 1, 1, 1, 1, 1, 7, 0, 0],
            [0, 0, 0, 7, 7, 1, 7, 7, 0, 0, 0],
            [0, 0, 0, 0, 7, 0, 7, 0, 0, 0, 0],
            [0, 0, 0, 0, 7, 0, 7, 0, 0, 0, 0],
            [0, 0, 0, 7, 7, 0, 7, 7, 0, 0, 0],
            [0, 0, 7, 0, 0, 0, 0, 0, 7, 0, 0],
            [0, 0, 7, 7, 7, 7, 7, 7, 7, 0, 0],
        ]
    },
    12: {
        "theme": "Z-запад",
        "grid": [
            [0, 7, 7, 7, 7, 7, 7, 7, 7, 7],
            [7, 5, 5, 5, 5, 5, 5, 5, 5, 7],
            [7, 5, 5, 5, 5, 5, 5, 5, 5, 7],
            [7, 6, 6, 6, 6, 5, 5, 5, 5, 7],
            [7, 6, 6, 6, 5, 5, 5, 5, 6, 7],
            [0, 7, 7, 5, 5, 5, 5, 6, 6, 7],
            [0, 7, 5, 5, 5, 5, 6, 6, 7, 0],
            [7, 5, 5, 5, 5, 6, 6, 7, 7, 0],
            [7, 5, 5, 5, 5, 5, 5, 5, 5, 7],
            [7, 5, 5, 5, 5, 5, 5, 5, 5, 7],
            [7, 6, 6, 6, 6, 6, 6, 6, 6, 7],
            [7, 6, 6, 6, 6, 6, 6, 6, 6, 7],
            [0, 7, 7, 7, 7, 7, 7, 7, 7, 0],
        ]
    },
    13: {
        "theme": "ПОКА НИЧЕГО",
        "grid": [
            [0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0],
            [0, 0, 0, 7, 7, 3, 3, 3, 3, 3, 7, 7, 0, 0, 0],
            [0, 0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0, 0],
            [0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0],
            [0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0],
            [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7],
            [7, 3, 7, 0, 0, 7, 7, 7, 7, 0, 0, 7, 7, 3, 7],
            [7, 3, 7, 0, 7, 7, 7, 3, 7, 0, 7, 7, 7, 3, 7],
            [7, 3, 3, 7, 7, 7, 3, 3, 3, 7, 7, 7, 3, 3, 7],
            [7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7],
            [0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 7, 3, 3, 7, 0],
            [0, 7, 3, 3, 3, 7, 7, 7, 7, 7, 3, 3, 3, 7, 0],
            [0, 0, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 0, 0],
            [0, 0, 0, 7, 7, 3, 3, 3, 3, 3, 7, 7, 0, 0, 0],
            [0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0]
        ]
    },
    14: {
        "theme": "ПОКА НИЧЕГО",
        "grid": [
            [0, 0, 0, 7, 0, 7, 0, 0, 0],
            [0, 0, 7, 1, 7, 1, 7, 0, 0],
            [0, 7, 1, 1, 1, 1, 1, 7, 0],
            [7, 1, 1, 1, 1, 1, 1, 1, 7],
            [0, 7, 1, 1, 1, 1, 1, 7, 0],
            [0, 0, 7, 1, 1, 1, 7, 0, 0],
            [0, 0, 0, 7, 1, 7, 0, 0, 0]
        ]
    },
    15: {
        "theme": "ПОКА НИЧЕГО",
        "grid": [
            [0, 0, 7, 7, 0, 0, 0, 7, 7, 0, 0],
            [0, 7, 1, 1, 7, 0, 7, 1, 1, 7, 0],
            [7, 1, 1, 1, 1, 7, 1, 1, 1, 1, 7],
            [7, 1, 1, 1, 1, 1, 1, 1, 1, 1, 7],
            [0, 7, 1, 1, 1, 1, 1, 1, 1, 7, 0],
            [0, 0, 7, 1, 1, 1, 1, 1, 7, 0, 0],
            [0, 0, 0, 7, 1, 1, 1, 7, 0, 0, 0],
            [0, 0, 0, 0, 7, 1, 7, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0],
        ]
    },
    16: {
        "theme": "ПОКА НИЧЕГО",
        "grid": [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 6, 6, 6, 6, 1, 6, 6, 6, 6, 0],
            [0, 6, 6, 6, 6, 1, 6, 6, 6, 6, 0],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
            [0, 6, 6, 6, 6, 1, 6, 6, 6, 6, 0],
            [0, 6, 6, 6, 6, 1, 6, 6, 6, 6, 0],
        ]
    },
    17: {
        "theme": "ПОКА НИЧЕГО",
        "grid": [
            [0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0],
            [0, 0, 0, 0, 4, 4, 0, 0, 0, 0, 0],
            [0, 0, 0, 4, 4, 4, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 4, 4, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 4, 4, 4, 0, 0, 0, 0],
            [0, 0, 0, 0, 4, 4, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 4, 4, 0, 0, 0, 0, 0],
        ]
    },
    18: {
        "theme": "ПОКА НИЧЕГО",
        "grid": [
            [0, 0, 0, 7, 7, 7, 0, 0, 0, 0],
            [0, 0, 7, 7, 7, 7, 7, 0, 0, 0],
            [0, 7, 7, 7, 7, 7, 7, 7, 0, 0],
            [7, 7, 7, 7, 7, 7, 7, 7, 7, 0],
            [7, 7, 7, 7, 1, 7, 7, 7, 7, 0],
            [7, 7, 7, 7, 1, 7, 7, 7, 7, 0],
            [7, 7, 7, 7, 1, 7, 7, 7, 7, 0],
            [7, 7, 7, 7, 1, 7, 7, 7, 7, 0],
            [0, 7, 7, 7, 7, 7, 7, 7, 0, 0],
            [0, 0, 7, 7, 7, 7, 7, 0, 0, 0],
        ]
    },
    19: {
        "theme": "ПОКА НИЧЕГО",
        "grid": [
            [0, 0, 8, 8, 8, 8, 8, 0, 0, 0],
            [0, 8, 8, 8, 8, 8, 8, 8, 0, 0],
            [8, 8, 8, 8, 8, 8, 8, 8, 8, 0],
            [8, 8, 8, 8, 8, 8, 8, 8, 8, 0],
            [8, 8, 8, 8, 8, 8, 8, 8, 8, 0],
            [0, 0, 8, 8, 8, 8, 8, 0, 0, 0],
            [0, 0, 0, 8, 8, 8, 8, 0, 0, 0],
            [0, 0, 0, 0, 8, 8, 0, 0, 0, 0],
            [0, 0, 0, 0, 8, 8, 0, 0, 0, 0],
            [0, 0, 0, 0, 8, 8, 0, 0, 0, 0],
        ]
    },
    20: {
        "theme": "ПОКА НИЧЕГО",
        "grid": [
            [0, 7, 7, 0, 0, 0, 7, 7, 0],
            [7, 1, 1, 7, 0, 7, 1, 1, 7],
            [7, 1, 1, 1, 7, 1, 1, 1, 7],
            [0, 7, 1, 1, 1, 1, 1, 7, 0],
            [0, 0, 7, 1, 1, 1, 7, 0, 0],
            [0, 0, 0, 7, 1, 7, 0, 0, 0],
            [0, 0, 0, 0, 7, 0, 0, 0, 0]
        ]
    }
}
def generate_random_grid(rows, cols):
    return [[random.randint(1, len(PALETTE_COLORS)) for _ in range(cols)] for _ in range(rows)]

def get_level_data(level_num):
    if level_num in LEVEL_DATA:
        data = LEVEL_DATA[level_num]
        return data["theme"], data["grid"]
    else:
        return "Random Level", generate_random_grid(10, 10)

def get_font(size):
    return pygame.font.SysFont(FONT_NAME, size)


class DatabaseManager:
    def __init__(self, db_file="game_progress.db"):
        self.db_file = db_file
        self.conn = sqlite3.connect(self.db_file)
        self.create_table()
        self.create_results_table()

    def create_table(self):
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS progress (
                id INTEGER PRIMARY KEY,
                score INTEGER NOT NULL,
                last_level INTEGER NOT NULL DEFAULT 0
            )
        """)
        self.conn.commit()
        cur.execute("PRAGMA table_info(progress)")
        columns = [info[1] for info in cur.fetchall()]
        if 'last_level' not in columns:
            cur.execute("ALTER TABLE progress ADD COLUMN last_level INTEGER NOT NULL DEFAULT 0")
            self.conn.commit()
        cur.execute("SELECT COUNT(*) FROM progress")
        if cur.fetchone()[0] == 0:
            cur.execute("INSERT INTO progress (score, last_level) VALUES (?, ?)", (0, 0))
            self.conn.commit()

    def create_results_table(self):
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS results (
                level_num INTEGER PRIMARY KEY,
                best_time REAL NOT NULL,
                stars INTEGER NOT NULL
            )
        """)
        self.conn.commit()

    def load_progress(self):
        cur = self.conn.cursor()
        cur.execute("SELECT score, last_level FROM progress WHERE id = 1")
        row = cur.fetchone()
        if row:
            return {"score": row[0], "last_level": row[1]}
        else:
            return {"score": 0, "last_level": 0}

    def save_progress(self, score, last_level):
        cur = self.conn.cursor()
        cur.execute("UPDATE progress SET score = ?, last_level = ? WHERE id = 1", (score, last_level))
        self.conn.commit()

    def load_result(self, level_num):
        cur = self.conn.cursor()
        cur.execute("SELECT best_time, stars FROM results WHERE level_num = ?", (level_num,))
        row = cur.fetchone()
        if row:
            return {"best_time": row[0], "stars": row[1]}
        else:
            return None

    def save_result(self, level_num, best_time, stars):
        existing = self.load_result(level_num)
        cur = self.conn.cursor()
        if existing:
            if best_time < existing["best_time"] or (best_time == existing["best_time"] and stars > existing["stars"]):
                cur.execute("UPDATE results SET best_time = ?, stars = ? WHERE level_num = ?",
                            (best_time, stars, level_num))
                self.conn.commit()
        else:
            cur.execute("INSERT INTO results (level_num, best_time, stars) VALUES (?, ?, ?)",
                        (level_num, best_time, stars))
            self.conn.commit()

    def close(self):
        self.conn.close()

class GameSettings:
    def __init__(self):
        self.brightness = DEFAULT_BRIGHTNESS
        self.difficulty_three = DEFAULT_THREE_STARS
        self.difficulty_two = DEFAULT_TWO_STARS
        self.difficulty_one = DEFAULT_ONE_STAR
        self.volume = 0.5

    def set_brightness(self, value):
        self.brightness = max(0.5, min(1.0, value))

    def set_difficulty(self, three, two, one):
        if 0 < three < two < one:
            self.difficulty_three = three
            self.difficulty_two = two
            self.difficulty_one = one

    def set_volume(self, value):
        self.volume = max(0.0, min(1.0, value))
        pygame.mixer.music.set_volume(self.volume)
        COLOR_SELECT_SOUND.set_volume(self.volume)
        LEVEL_COMPLETE_SOUND.set_volume(self.volume)
        WRONG_COLOR_SOUND.set_volume(self.volume)
        CORRECT_COLOR_SOUND.set_volume(self.volume)
        WELCOME_SOUND.set_volume(self.volume)

class Level:
    def __init__(self, level_num, brightness=DEFAULT_BRIGHTNESS):
        self.level_num = level_num
        self.brightness = brightness
        self.theme, self.solution_grid = get_level_data(level_num)
        self.rows = len(self.solution_grid)
        self.cols = len(self.solution_grid[0]) if self.rows > 0 else 0
        self.user_grid = [[0 for _ in range(self.cols)] for _ in range(self.rows)]
        self.completed = False

    def fill_cell(self, row, col, color_index):
        global WRONG_COLOR_SOUND, CORRECT_COLOR_SOUND
        self.user_grid[row][col] = color_index
        if color_index != 0:
            if self.user_grid[row][col] == self.solution_grid[row][col]:
                if CORRECT_COLOR_SOUND:
                    CORRECT_COLOR_SOUND.play()
            else:
                if WRONG_COLOR_SOUND:
                    WRONG_COLOR_SOUND.play()

    def is_completed(self):
        for r in range(self.rows):
            for c in range(self.cols):
                if self.user_grid[r][c] != self.solution_grid[r][c]:
                    return False
        self.completed = True
        return True

    def render(self, screen, offset):
        x_off, y_off = offset
        font = get_font(20)
        for r in range(self.rows):
            for c in range(self.cols):
                x = x_off + c * CELL_SIZE
                y = y_off + r * CELL_SIZE
                rect = pygame.Rect(x, y, CELL_SIZE, CELL_SIZE)
                if self.user_grid[r][c] != 0:
                    color = PALETTE_COLORS[self.user_grid[r][c]-1]
                    pygame.draw.rect(screen, color, rect)
                    if self.user_grid[r][c] != self.solution_grid[r][c]:
                        blink_alpha = int((math.sin(pygame.time.get_ticks()/200)+1)/2 * 150)
                        overlay = pygame.Surface((CELL_SIZE, CELL_SIZE))
                        overlay.set_alpha(blink_alpha)
                        overlay.fill(RED)
                        screen.blit(overlay, (x, y))
                else:
                    pygame.draw.rect(screen, OFF_WHITE, rect)
                pygame.draw.rect(screen, BLACK, rect, 1)
                num = self.solution_grid[r][c]
                text = font.render(str(num), True, BLACK)
                text_rect = text.get_rect(center=rect.center)
                screen.blit(text, text_rect)
        big_font = get_font(48)
        theme_text = big_font.render(self.theme, True, BLACK)
        theme_rect = theme_text.get_rect(center=(SCREEN_WIDTH//2, y_off - 40))
        screen.blit(theme_text, theme_rect)

def draw_dynamic_background(screen):
    t = pygame.time.get_ticks() / 1000.0
    shade = 20 + int((math.sin(t) + 1) / 2 * 20)
    dynamic_color = (shade, shade, shade)
    screen.fill(dynamic_color)

class ColoringGame:
    def confirm_purchase(self, level_num):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill(GRAY)
        self.screen.blit(overlay, (0, 0))
        font = get_font(36)
        prompt = font.render("Купить уровень за 500 очков?", True, OFF_WHITE)
        prompt_rect = prompt.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 60))
        self.screen.blit(prompt, prompt_rect)
        buy_btn = pygame.Rect(SCREEN_WIDTH//2 - 220, SCREEN_HEIGHT//2, 200, 50)
        cancel_btn = pygame.Rect(SCREEN_WIDTH//2 + 20, SCREEN_HEIGHT//2, 200, 50)
        pygame.draw.rect(self.screen, ORANGE, buy_btn)
        pygame.draw.rect(self.screen, ORANGE, cancel_btn)
        pygame.draw.rect(self.screen, BLACK, buy_btn, 2)
        pygame.draw.rect(self.screen, BLACK, cancel_btn, 2)
        buy_text = font.render("Купить", True, BLACK)
        cancel_text = font.render("Отмена", True, BLACK)
        buy_rect = buy_text.get_rect(center=buy_btn.center)
        cancel_rect = cancel_text.get_rect(center=cancel_btn.center)
        self.screen.blit(buy_text, buy_rect)
        self.screen.blit(cancel_text, cancel_rect)
        pygame.display.flip()
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.exit_game()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    if buy_btn.collidepoint(pos):
                        return True
                    elif cancel_btn.collidepoint(pos):
                        return False


    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()
        self.db = DatabaseManager()
        progress = self.db.load_progress()
        self.score = progress["score"]
        self.last_level = progress["last_level"]
        self.settings = GameSettings()
        self.current_level_num = 1
        self.level = Level(self.current_level_num, brightness=self.settings.brightness)
        self.state = "menu"
        self.selected_palette_index = 1  # 0 = ластик, 1-8 = цвета
        self.selected_color = PALETTE_COLORS[self.selected_palette_index - 1]
        self.level_offset = self.calc_level_offset()
        self.palette_buttons = self.create_palette_buttons()
        self.menu_buttons = []
        self.level_start_time = 0

    def calc_level_offset(self):
        grid_width = self.level.cols * CELL_SIZE
        grid_height = self.level.rows * CELL_SIZE
        offset_x = (SCREEN_WIDTH - grid_width) // 2
        offset_y = (SCREEN_HEIGHT - grid_height) // 2
        return (offset_x, offset_y)

    def create_palette_buttons(self):
        buttons = []
        button_size = 50
        margin = 10
        total_width = (len(PALETTE_COLORS) + 1) * button_size + (len(PALETTE_COLORS)) * margin
        start_x = (SCREEN_WIDTH - total_width) // 2
        y = SCREEN_HEIGHT - button_size - 20
        font = get_font(20)
        for i, color in enumerate(PALETTE_COLORS):
            rect = pygame.Rect(start_x + i*(button_size+margin), y, button_size, button_size)
            buttons.append((rect, color, i+1))
        eraser_rect = pygame.Rect(start_x + len(PALETTE_COLORS)*(button_size+margin), y, button_size, button_size)
        buttons.append((eraser_rect, OFF_WHITE, 0))
        return buttons

    def draw_palette(self):
        self.palette_buttons = self.create_palette_buttons()
        font = get_font(20)
        for rect, value, number in self.palette_buttons:
            if number == 0:
                pygame.draw.rect(self.screen, OFF_WHITE, rect)
                pygame.draw.rect(self.screen, BLACK, rect, 2)
                eraser_text = font.render(ERASER_LABEL, True, BLACK)
                eraser_rect = eraser_text.get_rect(center=rect.center)
                self.screen.blit(eraser_text, eraser_rect)
            else:
                pygame.draw.rect(self.screen, value, rect)
                pygame.draw.rect(self.screen, BLACK, rect, 2)
                num_text = font.render(str(number), True, BLACK)
                num_rect = num_text.get_rect(center=rect.center)
                self.screen.blit(num_text, num_rect)
                if number == self.selected_palette_index:
                    overlay = pygame.Surface((rect.width, rect.height))
                    overlay.set_alpha(100)
                    overlay.fill(BLACK)
                    self.screen.blit(overlay, rect.topleft)

    def draw_exit_button(self):
        pygame.draw.rect(self.screen, ORANGE, EXIT_BUTTON_RECT)
        font = get_font(24)
        text = font.render("В меню", True, BLACK)
        text_rect = text.get_rect(center=EXIT_BUTTON_RECT.center)
        self.screen.blit(text, text_rect)

    def draw_menu(self):
        draw_dynamic_background(self.screen)
        font_large = get_font(72)
        title = font_large.render("Coloring Game", True, OFF_WHITE)
        title_rect = title.get_rect(center=(SCREEN_WIDTH//2, 80))
        self.screen.blit(title, title_rect)
        font_medium = get_font(36)
        instruction = font_medium.render("Выберите уровень", True, OFF_WHITE)
        inst_rect = instruction.get_rect(center=(SCREEN_WIDTH//2, 150))
        self.screen.blit(instruction, inst_rect)
        levels_per_row = 5
        btn_width = LEVEL_BUTTON_WIDTH
        btn_height = LEVEL_BUTTON_HEIGHT
        margin = LEVEL_BUTTON_MARGIN
        total_width = levels_per_row * btn_width + (levels_per_row - 1) * margin
        start_x = (SCREEN_WIDTH - total_width) // 2
        start_y = 220
        self.menu_buttons = []
        for i in range(1, TOTAL_LEVELS+1):
            row = (i-1) // levels_per_row
            col = (i-1) % levels_per_row
            x = start_x + col * (btn_width + margin)
            y = start_y + row * (btn_height + margin)
            rect = pygame.Rect(x, y, btn_width, btn_height)
            if i <= self.last_level:
                color = DARK_GREEN
            elif i == self.last_level + 1:
                color = GREEN
            else:
                color = GRAY
            pygame.draw.rect(self.screen, color, rect)
            pygame.draw.rect(self.screen, BLACK, rect, 2)
            num_text = font_medium.render(str(i), True, BLACK)
            num_rect = num_text.get_rect(center=rect.center)
            self.screen.blit(num_text, num_rect)
            if i <= self.last_level:
                result = self.db.load_result(i)
                if result:
                    stars = result["stars"]
                    star_text = get_font(24).render("*" * stars, True, YELLOW)
                    star_rect = star_text.get_rect(center=(rect.centerx, rect.top - 15))
                    self.screen.blit(star_text, star_rect)
            self.menu_buttons.append(("level", rect, i, i <= self.last_level+1))
        settings_btn = pygame.Rect(20, SCREEN_HEIGHT - 80, 200, 50)
        pygame.draw.rect(self.screen, ORANGE, settings_btn)
        pygame.draw.rect(self.screen, BLACK, settings_btn, 2)
        settings_text = font_medium.render("Настройки", True, BLACK)
        s_rect = settings_text.get_rect(center=settings_btn.center)
        self.screen.blit(settings_text, s_rect)
        self.menu_buttons.append(("settings", settings_btn))
        score_text = font_medium.render(f"Счет: {self.score}", True, OFF_WHITE)
        self.screen.blit(score_text, (20, 20))
        pygame.display.flip()

    def show_level_options(self, level_num):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill(GRAY)
        self.screen.blit(overlay, (0,0))
        font = get_font(36)
        prompt = font.render("Выберите действие", True, OFF_WHITE)
        prompt_rect = prompt.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 60))
        self.screen.blit(prompt, prompt_rect)
        replay_btn = pygame.Rect(SCREEN_WIDTH//2 - 220, SCREEN_HEIGHT//2, 200, 50)
        view_btn = pygame.Rect(SCREEN_WIDTH//2 + 20, SCREEN_HEIGHT//2, 200, 50)
        pygame.draw.rect(self.screen, ORANGE, replay_btn)
        pygame.draw.rect(self.screen, ORANGE, view_btn)
        pygame.draw.rect(self.screen, BLACK, replay_btn, 2)
        pygame.draw.rect(self.screen, BLACK, view_btn, 2)
        replay_text = font.render("Перепройти", True, BLACK)
        view_text = font.render("Посмотреть", True, BLACK)
        replay_rect = replay_text.get_rect(center=replay_btn.center)
        view_rect = view_text.get_rect(center=view_btn.center)
        self.screen.blit(replay_text, replay_rect)
        self.screen.blit(view_text, view_rect)
        pygame.display.flip()
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.exit_game()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    if replay_btn.collidepoint(pos):
                        return "replay"
                    elif view_btn.collidepoint(pos):
                        return "view"

    def confirm_purchase(self, level_num):
        if self.score < PURCHASE_COST:
            self.show_error_message("Недостаточно очков!")
            return False

        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill(GRAY)
        self.screen.blit(overlay, (0, 0))

        font = get_font(36)
        prompt = font.render("Купить уровень за 500 очков?", True, OFF_WHITE)
        prompt_rect = prompt.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 60))
        self.screen.blit(prompt, prompt_rect)

        buy_btn = pygame.Rect(SCREEN_WIDTH // 2 - 220, SCREEN_HEIGHT // 2, 200, 50)
        cancel_btn = pygame.Rect(SCREEN_WIDTH // 2 + 20, SCREEN_HEIGHT // 2, 200, 50)

        pygame.draw.rect(self.screen, ORANGE, buy_btn)
        pygame.draw.rect(self.screen, ORANGE, cancel_btn)
        pygame.draw.rect(self.screen, BLACK, buy_btn, 2)
        pygame.draw.rect(self.screen, BLACK, cancel_btn, 2)

        buy_text = font.render("Купить", True, BLACK)
        cancel_text = font.render("Отмена", True, BLACK)
        buy_rect = buy_text.get_rect(center=buy_btn.center)
        cancel_rect = cancel_text.get_rect(center=cancel_btn.center)

        self.screen.blit(buy_text, buy_rect)
        self.screen.blit(cancel_text, cancel_rect)

        pygame.display.flip()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.exit_game()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    if buy_btn.collidepoint(pos):
                        return True
                    elif cancel_btn.collidepoint(pos):
                        return False

    def show_error_message(self, message):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill(GRAY)
        self.screen.blit(overlay, (0, 0))

        font = get_font(36)
        error_text = font.render(message, True, RED)
        error_rect = error_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 40))
        self.screen.blit(error_text, error_rect)

        ok_btn = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + 20, 200, 50)
        pygame.draw.rect(self.screen, ORANGE, ok_btn)
        pygame.draw.rect(self.screen, BLACK, ok_btn, 2)

        ok_text = font.render("Ок", True, BLACK)
        ok_rect = ok_text.get_rect(center=ok_btn.center)
        self.screen.blit(ok_text, ok_rect)

        pygame.display.flip()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.exit_game()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if ok_btn.collidepoint(event.pos):
                        return

    def handle_menu_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.exit_game()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                for item in self.menu_buttons:
                    if item[0] == "settings":
                        btn = item[1]
                        if btn.collidepoint(pos):
                            self.state = "settings"
                    elif item[0] == "level":
                        rect, level_num, unlocked = item[1], item[2], item[3]
                        if rect.collidepoint(pos):
                            if level_num <= self.last_level:
                                choice = self.show_level_options(level_num)
                                if choice == "replay":
                                    self.start_level(level_num)
                                elif choice == "view":
                                    self.level = Level(level_num, brightness=self.settings.brightness)
                                    self.level_offset = self.calc_level_offset()
                                    self.state = "view_solution"
                            elif unlocked:
                                self.start_level(level_num)
                            else:
                                if self.confirm_purchase(level_num):
                                    if self.score >= PURCHASE_COST:
                                        self.score -= PURCHASE_COST
                                        self.last_level = level_num
                                        self.db.save_progress(self.score, self.last_level)
                                        self.start_level(level_num)
                                    else:
                                        self.show_purchase_error("Недостаточно очков для покупки уровня!")

    def start_level(self, level_num):
        self.current_level_num = level_num
        self.level = Level(level_num, brightness=self.settings.brightness)
        self.level_offset = self.calc_level_offset()
        self.state = "playing"
        self.level_start_time = pygame.time.get_ticks()

    def handle_playing_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.exit_game()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if EXIT_BUTTON_RECT.collidepoint(pos):
                    self.state = "menu"
                    return
                for rect, color, number in self.palette_buttons:
                    if rect.collidepoint(pos):
                        self.selected_palette_index = number
                        if number == 0:
                            self.selected_color = None
                        else:
                            self.selected_color = color
                        COLOR_SELECT_SOUND.play()
                        break
                grid_rect = pygame.Rect(self.level_offset[0], self.level_offset[1],
                                        self.level.cols * CELL_SIZE, self.level.rows * CELL_SIZE)
                if grid_rect.collidepoint(pos):
                    rel_x = pos[0] - self.level_offset[0]
                    rel_y = pos[1] - self.level_offset[1]
                    col = rel_x // CELL_SIZE
                    row = rel_y // CELL_SIZE
                    if self.selected_palette_index == 0:
                        self.level.fill_cell(row, col, 0)
                    else:
                        self.level.fill_cell(row, col, self.selected_palette_index)
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    pos = pygame.mouse.get_pos()
                    grid_rect = pygame.Rect(self.level_offset[0], self.level_offset[1],
                                            self.level.cols * CELL_SIZE, self.level.rows * CELL_SIZE)
                    if grid_rect.collidepoint(pos):
                        rel_x = pos[0] - self.level_offset[0]
                        rel_y = pos[1] - self.level_offset[1]
                        col = rel_x // CELL_SIZE
                        row = rel_y // CELL_SIZE
                        if self.selected_palette_index == 0:
                            self.level.fill_cell(row, col, 0)
                        else:
                            self.level.fill_cell(row, col, self.selected_palette_index)

    def update(self):
        if self.state == "playing":
            elapsed = (pygame.time.get_ticks() - self.level_start_time) / 1000.0
            if elapsed > self.settings.difficulty_one and not self.level.is_completed():
                self.state = "gameover"
            elif self.level.is_completed():
                LEVEL_COMPLETE_SOUND.play()
                if elapsed <= self.settings.difficulty_three:
                    stars = 3
                    bonus = 100
                elif elapsed <= self.settings.difficulty_two:
                    stars = 2
                    bonus = 50
                elif elapsed <= self.settings.difficulty_one:
                    stars = 1
                    bonus = 30
                self.score += bonus
                if self.current_level_num > self.last_level:
                    self.last_level = self.current_level_num
                self.db.save_progress(self.score, self.last_level)
                self.db.save_result(self.current_level_num, elapsed, stars)
                self.state = "menu"

    def render(self):
        if self.state == "playing":
            draw_dynamic_background(self.screen)
            self.level.render(self.screen, self.level_offset)
            self.draw_exit_button()
            self.draw_palette()
            font = get_font(28)
            score_text = font.render(f"Счет: {self.score}", True, SOFT_RED)
            self.screen.blit(score_text, (20, 80))
            elapsed = (pygame.time.get_ticks() - self.level_start_time) / 1000.0
            timer_text = font.render(f"Время: {elapsed:.1f} с", True, SOFT_RED)
            self.screen.blit(timer_text, (SCREEN_WIDTH - 250, 20))
            pygame.display.flip()

    def draw_gameover(self):
        self.screen.fill(OFF_WHITE)
        font_large = get_font(72)
        over_text = font_large.render("GAME OVER ;(", True, RED)
        over_rect = over_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 50))
        self.screen.blit(over_text, over_rect)
        replay_btn = pygame.Rect(SCREEN_WIDTH//2 - 220, SCREEN_HEIGHT//2 + 10, 200, 50)
        exit_btn = pygame.Rect(SCREEN_WIDTH//2 + 20, SCREEN_HEIGHT//2 + 10, 200, 50)
        pygame.draw.rect(self.screen, ORANGE, replay_btn)
        pygame.draw.rect(self.screen, ORANGE, exit_btn)
        pygame.draw.rect(self.screen, BLACK, replay_btn, 2)
        pygame.draw.rect(self.screen, BLACK, exit_btn, 2)
        replay_text = get_font(36).render("Перепройти", True, BLACK)
        exit_text = get_font(36).render("Выход", True, BLACK)
        replay_rect = replay_text.get_rect(center=replay_btn.center)
        exit_rect = exit_text.get_rect(center=exit_btn.center)
        self.screen.blit(replay_text, replay_rect)
        self.screen.blit(exit_text, exit_rect)
        pygame.display.flip()
        return replay_btn, exit_btn

    def handle_gameover_events(self, replay_btn, exit_btn):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.exit_game()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if replay_btn.collidepoint(pos):
                    self.start_level(self.current_level_num)
                elif exit_btn.collidepoint(pos):
                    self.exit_game()

    def draw_solution_view(self):
        self.screen.fill(OFF_WHITE)
        font = get_font(20)
        for r in range(self.level.rows):
            for c in range(self.level.cols):
                x = self.level_offset[0] + c * CELL_SIZE
                y = self.level_offset[1] + r * CELL_SIZE
                rect = pygame.Rect(x, y, CELL_SIZE, CELL_SIZE)
                color = PALETTE_COLORS[self.level.solution_grid[r][c]-1]
                pygame.draw.rect(self.screen, color, rect)
                pygame.draw.rect(self.screen, BLACK, rect, 1)
        result = self.db.load_result(self.current_level_num)
        font36 = get_font(36)
        if result:
            time_text = f"Время: {result['best_time']:.1f} с"
            stars_text = "*" * result["stars"]
        else:
            time_text = "Нет результата"
            stars_text = ""
        time_surface = font36.render(time_text, True, BLACK)
        stars_surface = font36.render(stars_text, True, BLACK)
        time_rect = time_surface.get_rect(center=(SCREEN_WIDTH//2, 80))
        stars_rect = stars_surface.get_rect(center=(SCREEN_WIDTH//2, 120))
        self.screen.blit(time_surface, time_rect)
        self.screen.blit(stars_surface, stars_rect)
        back_btn = pygame.Rect(SCREEN_WIDTH//2 - 100, SCREEN_HEIGHT - 100, 200, 50)
        pygame.draw.rect(self.screen, ORANGE, back_btn)
        pygame.draw.rect(self.screen, BLACK, back_btn, 2)
        back_text = get_font(36).render("Назад", True, BLACK)
        back_rect = back_text.get_rect(center=back_btn.center)
        self.screen.blit(back_text, back_rect)
        pygame.display.flip()
        return back_btn

    def handle_solution_view_events(self, back_btn):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.exit_game()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if back_btn.collidepoint(pos):
                    self.state = "menu"

    def draw_settings(self):
        self.screen.fill(OFF_WHITE)
        font_large = get_font(72)
        title = font_large.render("Настройки", True, BLACK)
        title_rect = title.get_rect(center=(SCREEN_WIDTH//2, 80))
        self.screen.blit(title, title_rect)
        font_medium = get_font(36)
        brightness_text = font_medium.render(f"Яркость: {self.settings.brightness:.2f}", True, BLACK)
        self.screen.blit(brightness_text, (100, 150))
        diff_text = font_medium.render("Сложность (сек):", True, BLACK)
        self.screen.blit(diff_text, (100, 210))
        three_slider_rect = pygame.Rect(100, 260, 300, 20)
        two_slider_rect = pygame.Rect(100, 320, 300, 20)
        pygame.draw.rect(self.screen, GRAY, three_slider_rect)
        pygame.draw.rect(self.screen, GRAY, two_slider_rect)
        three_pos = three_slider_rect.x + int((self.settings.difficulty_three / DEFAULT_ONE_STAR) * three_slider_rect.width)
        two_pos = two_slider_rect.x + int((self.settings.difficulty_two / DEFAULT_ONE_STAR) * two_slider_rect.width)
        pygame.draw.rect(self.screen, ORANGE, (three_pos-5, three_slider_rect.y-5, 10, three_slider_rect.height+10))
        pygame.draw.rect(self.screen, ORANGE, (two_pos-5, two_slider_rect.y-5, 10, two_slider_rect.height+10))
        three_label = font_medium.render(f"3 звезды: {self.settings.difficulty_three} с", True, BLACK)
        two_label = font_medium.render(f"2 звезды: {self.settings.difficulty_two} с", True, BLACK)
        self.screen.blit(three_label, (420, 250))
        self.screen.blit(two_label, (420, 310))
        back_btn = pygame.Rect(20, SCREEN_HEIGHT - 80, 200, 50)
        pygame.draw.rect(self.screen, ORANGE, back_btn)
        pygame.draw.rect(self.screen, BLACK, back_btn, 2)
        back_text = font_medium.render("Назад", True, BLACK)
        b_rect = back_text.get_rect(center=back_btn.center)
        self.screen.blit(back_text, b_rect)
        pygame.display.flip()
        self.settings_buttons = [("back", back_btn), ("three_slider", three_slider_rect), ("two_slider", two_slider_rect)]

    def handle_settings_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.exit_game()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                for item in self.settings_buttons:
                    if item[0] == "back":
                        btn = item[1]
                        if btn.collidepoint(pos):
                            self.state = "menu"
                    elif item[0] == "three_slider":
                        slider = item[1]
                        if slider.collidepoint(pos):
                            rel_x = pos[0] - slider.x
                            value = int((rel_x / slider.width) * DEFAULT_ONE_STAR)
                            value = max(5, min(300, value))
                            self.settings.difficulty_three = value
                    elif item[0] == "two_slider":
                        slider = item[1]
                        if slider.collidepoint(pos):
                            rel_x = pos[0] - slider.x
                            value = int((rel_x / slider.width) * DEFAULT_ONE_STAR)
                            value = max(self.settings.difficulty_three+1, min(300, value))
                            self.settings.difficulty_two = value
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.state = "menu"

    def run(self):
        while True:
            if self.state == "menu":
                self.draw_menu()
                self.handle_menu_events()
            elif self.state == "settings":
                self.draw_settings()
                self.handle_settings_events()
            elif self.state == "playing":
                self.handle_playing_events()
                self.update()
                self.render()
            elif self.state == "gameover":
                replay_btn, exit_btn = self.draw_gameover()
                self.handle_gameover_events(replay_btn, exit_btn)
            elif self.state == "view_solution":
                back_btn = self.draw_solution_view()
                self.handle_solution_view_events(back_btn)
            self.clock.tick(FPS)
            self.dummy_periodic_task()

    def exit_game(self):
        self.db.close()
        pygame.quit()
        sys.exit()

    def dummy_periodic_task(self):
        total = 0
        for i in range(10):
            for j in range(10):
                total += (i * j) % (j + 1)
        return total

def dummy_function_1():
    s = ""
    for i in range(100):
        s += chr(65 + (i % 26))
    return s

def dummy_function_2():
    lst = []
    for i in range(50):
        lst.append(math.sqrt(i))
    return lst

def dummy_loop():
    total = 0
    for i in range(50):
        for j in range(50):
            total += i * j
    return total

def dummy_recursive(n):
    if n <= 0:
        return 0
    return n + dummy_recursive(n - 1)

def dummy_extra():
    result = 1
    for i in range(1, 20):
        result *= i
    return result

class DummyClass:
    def __init__(self, value):
        self.value = value
        self.history = []
    def add(self, amount):
        self.value += amount
        self.history.append(self.value)
    def subtract(self, amount):
        self.value -= amount
        self.history.append(self.value)
    def multiply(self, factor):
        self.value *= factor
        self.history.append(self.value)
    def divide(self, divisor):
        if divisor != 0:
            self.value /= divisor
        self.history.append(self.value)
    def get_history(self):
        return self.history
def extra_padding():
    total = 0
    for i in range(100):
        for j in range(10):
            total += (i + j) % (j + 1)
    return total
def another_dummy():
    lst = [random.randint(0, 100) for _ in range(100)]
    return sorted(lst)
def final_dummy():
    values = [dummy_function_1(), dummy_function_2(), dummy_loop(), dummy_recursive(10)]
    summary = {
        "dummy_extra": dummy_extra(),
        "extra_padding": extra_padding(),
        "another_dummy": another_dummy()
    }
    return values, summary
ultimate_result = final_dummy()
def main():
    pygame.mixer.init()

    global BACKGROUND_MUSIC, COLOR_SELECT_SOUND, LEVEL_COMPLETE_SOUND
    global WRONG_COLOR_SOUND, CORRECT_COLOR_SOUND, WELCOME_SOUND

    try:
        BACKGROUND_MUSIC = "1.mp3"
        COLOR_SELECT_SOUND = pygame.mixer.Sound("2.mp3")
        LEVEL_COMPLETE_SOUND = pygame.mixer.Sound("3.mp3")
        WRONG_COLOR_SOUND = pygame.mixer.Sound("4.mp3")
        CORRECT_COLOR_SOUND = pygame.mixer.Sound("5.mp3")
        WELCOME_SOUND = pygame.mixer.Sound("6.mp3")

        pygame.mixer.music.load(BACKGROUND_MUSIC)
        pygame.mixer.music.play(-1)

        WELCOME_SOUND.play()

    except pygame.error as e:
        print(f"Ошибка загрузки звуков: {e}")
        WRONG_COLOR_SOUND = None
        CORRECT_COLOR_SOUND = None
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Coloring Game")
    game = ColoringGame(screen)
    game.run()
if __name__ == "__main__":
    main()
